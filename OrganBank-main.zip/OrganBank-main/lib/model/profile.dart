import 'package:flutter/material.dart';

class Profile {
  String name;
  String phoneNumber;
  String location;
  Icon icon;

  Profile(
    this.name,
    this.phoneNumber,
    this.location,
    this.icon,
  );
}
