import 'package:flutter/material.dart';

class Organ {
  String organType;
  String bloodType;
  String date;
  Icon icon;

  Organ(
    this.bloodType,
    this.date,
    this.organType,
    this.icon,
  );
}
